
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.14.4'
version = '1.14.4'
full_version = '1.14.4'
git_revision = '83419d6462461110035fa27e322efed557c739ac'
release = True

if not release:
    version = full_version
